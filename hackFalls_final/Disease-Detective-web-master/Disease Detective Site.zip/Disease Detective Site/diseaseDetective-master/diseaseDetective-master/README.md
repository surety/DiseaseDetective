# diseaseDetective
Identify skin diseases using TensorFlow.js MobileNet algorithm
